<div class="container">
        <center>
          <h1>Campanhas</h1>
        </center>
        <br>
        <br>
        <div class="row">
          <div class="col-md-4">
			<br>
            <br>
            <center>
				<div class="card" style="max-width: 30rem;">  
					<div class="card-header">Dia Mundial de Luta Contra a Aids – 30 anos</div>
						<a href="#">
							<img class="card-img" src="Imgs/ativista.jpg" height="200" alt="Card image cap">
						</a>    
				</div>
            </center>    
          </div>
          <div class="col-md-4">
			<br>
			<br>
            <center>
				<div class="card" style="max-width: 30rem;">
					<div class="card-header">Doação de Órgãos</div>
						<a href="#">
							<img class="card-img" src="Imgs/doeorgaos.jpg" height="200" alt="Card image cap">
						</a>
				</div>
            </center>
          </div>
          <div class="col-md-4">
			<br>
			<br>
            <center>
				<div class="card" style="max-width: 30rem;">
					<div class="card-header">Campanha Campanha Nacional Contra a Tuberculose</div>
					<a href="#">
						<img class="card-img" src="Imgs/tuberculose.png" height="200" alt="Card image cap">
					</a>
				</div>
            </center>
          </div>
      </div>
		<div class="row">
			<div class="col-md-4">
				<br>
				<br>
				<center>
				<div class="card" style="max-width: 30rem;">
					<div class="card-header">Programa Nacional de Imunizações</div>
						<a href="#">
							<img class="card-img" src="Imgs/caxumba.jpg" height="200" alt="Card image cap">
						</a>
				</div>
				</center>
          </div>
		  <div class="col-md-4">
				<br>
				<br>
				<center>
				<div class="card" style="max-width: 30rem;">
					<div class="card-header">Semana Mundial da Amamentação</div>
						<a href="#">
							<img class="card-img" src="Imgs/amamentacao.jpg" height="200" alt="Card image cap">
						</a>
				</div>
				</center>
          </div>
		  <div class="col-md-4">
				<br>
				<br>
				<center>
				<div class="card" style="max-width: 30rem;">
					<div class="card-header">Campanha Doação de Leite</div>
						<a href="#">
							<img class="card-img" src="Imgs/leite.jpg" height="200" alt="Card image cap">
						</a>
				</div>
				</center>
          </div>
		  
		</div>
		<div class ="row">
		<div class="col-md-4">
				<br>
				<br>
				<center>
				<div class="card" style="max-width: 30rem;">
					<div class="card-header">Prevenção o Suicídio</div>
						<a href="#">
							<img class="card-img" src="Imgs/prevenir.jpg" height="200" alt="Card image cap">
						</a>
				</div>
				</center>
          </div>
		  <div class="col-md-4">
				<br>
				<br>
				<center>
				<div class="card" style="max-width: 30rem;">
					<div class="card-header">Campanha HPV</div>
						<a href="#">
							<img class="card-img" src="Imgs/hpv.jpg" height="200" alt="Card image cap">
						</a>
				</div>
				</center>
          </div>
		  <div class="col-md-4">
				<br>
				<br>
				<center>
				<div class="card" style="max-width: 30rem;">
					<div class="card-header">Campanha Nacional de Vacinação contra a Influenza</div>
						<a href="#">
							<img class="card-img" src="Imgs/BUSDOOR.jpg" height="200" alt="Card image cap">
						</a>
				</div>
				</center>
          </div>
		</div>
    </div>