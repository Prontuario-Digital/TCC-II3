 <ul>
        <li style="margin-left: 150px;"><a href="./index.php">Prontuário Digital</a></li>
        <li><a href="./sobre.php">Sobre</a></li>
        <li><a class="ativo" a href="./funcionalidades.php">Funcionalidades</a></li>
        <li><a href="./contato.php">Contato</a></li>    
      </ul>