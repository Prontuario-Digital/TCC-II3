 <div class="container">
  	<br>
  	<center>
  		<h1>Funcionalidades</h1>
  	</center>
  	<br>
    <div class="row">
      <div class="col-md-4">
        <center>
        <a href="#">
			<div class="card bg-light mb-3 " style="max-width: 18rem;">
				<div class="card-header bg-transparent">
					<img src="Imgs/minha.png" alt="Card image cap" width="128" height="128">
				</div>
        </a>    
				<div class="card-body text">
					<h5 class="card-title">Minha Saúde</h5>
					<p class="card-text">Seu historíco médico</p>
				</div>
			</div>
      </center>
      </div>
      <div class="col-md-4">
        <center>
        <a href="#">
			<div class="card bg-light mb-3" style="max-width: 18rem;">
				<div class="card-header bg-transparent">
					<img src="Imgs/remedio.png" alt="Cinque Terre" width="128" height="128">
				</div>
        </a>    
				<div class="card-body text">
					<h5 class="card-title">Medicamentos</h5>
					<p class="card-text">Farmácia Populares proxímas</p>
				</div>
			</div>
		</center>
      </div>
      <div class="col-md-4">
        <center>
        <a href="#">
			<div class="card bg-light mb-3" style="max-width: 18rem;">
				<div class="card-header bg-transparent">
				<img src="Imgs/atendimento.png" alt="Cinque Terre" width="128" height="128">
			</div>
        </a>    
				<div class="card-body text">
					<h5 class="card-title">Atendimento</h5>
					<p class="card-text">Histórico de atendimento</p>
				</div>
			</div>
		</center>
      <br>
      </div>
      <div class="col-md-4">
        <center>
        <a href="#">
			<div class="card bg-light mb-3" style="max-width: 18rem;">
				<div class="card-header bg-transparent">
					<img src="Imgs/servico.png" class=" " alt="Cinque Terre" width="128" height="128">
				</div>
        </a>    
				<div class="card-body text">
					<h5 class="card-title">Serviços de saúde</h5>
					<p class="card-text">Localize um próximo a você</p>
				</div>
			</div>
		</center>
      </div>
      <div class="col-md-4">
        <center>
		<a href="#">
			<div class="card bg-light mb-3" style="max-width: 18rem;">
				<div class="card-header bg-transparent">
					<img src="Imgs/phone.png" class=" " alt="Cinque Terre" width="128" height="128">
				</div>
		</a>		
				<div class="card-body text">
					<h5 class="card-title">Ouvidoria</h5>
					<p class="card-text">Entre em contato</p>
				</div>
			</div>
		</center>
      </div>
      <div class="col-md-4">
        <center>
        <a href="#">
			<div class="card bg-light mb-3" style="max-width: 18rem;">
				<div class="card-header bg-transparent">
					<img src="Imgs/hospitais.png" class=" " alt="Cinque Terre" width="128" height="128">
				</div>
		</a>		
				<div class="card-body text">
					<h5 class="card-title">Hospitais</h5>
					<p class="card-text">Encontre o hospital mais próximo de você que utiliza o Prontuário Digital.</p>
				</div>
        </div>
      </center>
      </div>
      <br>
      <br>
    </div>
  </div>