<div class="container" style="padding-top: 100px;">
	<div id="myCarousel" class="carousel slide" data-ride="carousel">
		<div class="carousel-inner">
			<div class="item active">
				<center>
					<img src="./Imgs/carousel1.png"  width="1200" height="500" alt="slide1">
				</center>
				<div class="carousel-caption">
					<h3>Teste 1</h3>
					<p>blablablabla<p>
				</div>
			</div>
			<div class="item">
				<center>
					<img  src="./Imgs/carousel3.png"  width="1200" height="500" alt="slide2">
				</center>
				<div class="carousel-caption">
					<h3>Teste 2</h3>
					<p>blabalablabl</p>
				</div>
			</div>
		</div>
	</div>
</div>	