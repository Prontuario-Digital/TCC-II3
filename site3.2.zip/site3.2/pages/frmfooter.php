<br>
<footer id="footer">
	<div class="container-fluid">
		<div class="copyright"> Prontuário Digital © <span id="copyright-year"></span>.&nbsp;&nbsp;<a href="politica.html"> Política de Privacidade </a></div>
    </div>
</footer>