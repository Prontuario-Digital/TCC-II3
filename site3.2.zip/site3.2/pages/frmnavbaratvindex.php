 <ul>
        <li style="margin-left: 150px;"><a class="ativo" href="./index.php">Prontuário Digital</a></li>
        <li><a href="./sobre.php">Sobre</a></li>
        <li><a href="./funcionalidades.php">Funcionalidades</a></li>
        <li><a href="./contato.php">Contato</a></li> 
        <li class="login"><a href="./cadastro.php">Cadastro</a></li> 
        <li class="login"><a href="#" data-toggle="modal" data-target="#modalLogin" > Login </a> </a></li>      
      </ul>