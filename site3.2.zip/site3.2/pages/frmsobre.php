<div class = "container-fluid bg-1 text-center" style="padding-top: 55px;" >
      <div class = "row" id = "quemsomos">
        <h1 class = "titulotextos"> Sobre </h1>
      </div>
       <div class = "container">
          <p class = "lead">
            O Prontuário Digital é um sistema web criado para lorem ipsum empresa de design de interiores formada por profissionais habilitados que tem como seu principal objetivo satisfazer todas as necessidades do ponto de vista de decoração de seus milhares de clientes, conquistados em mais de duas décadas de trabalho com compromisso, qualidade, rapidez e respeito ao cliente. O mercado de design de interiores consiste na arte de planejar e organizar espaços, escolhendo e/ou combinando os diversos elementos de um ambiente, estabelecendo relações estéticas e funcionais, em relação ao que se pretende produzir. Trabalhamos na criação, no desenvolvimento e execução dos projetos e no planejamento e acompanhamento das obras residenciais e comerciais, fazendo estudos preliminares, projetos em 3D com imagens renderizadas, projetos executivos, projetos de paisagismo e de iluminação.
          </p>
          <hr>
          <h1 class = "titulotextos"> Missão </h1>
           <p class = "lead">
            O Prontuário Digital tem como missão lorem ipsum empresa de design de interiores formada por profissionais habilitados que tem como seu principal objetivo satisfazer todas as necessidades do ponto de vista de decoração de seus milhares de clientes, conquistados em mais de duas décadas de trabalho com compromisso, qualidade, rapidez e respeito ao cliente.
          </p>
          <hr>
          <h1 class = "titulotextos"> Visão </h1>
           <p class = "lead">
            O Prontuário Digital visa lorem ipsum para lorem ipsum empresa de design de interiores formada por profissionais habilitados que tem como seu principal objetivo satisfazer todas as necessidades do ponto de vista de decoração de seus milhares de clientes, conquistados em mais de duas décadas de trabalho com compromisso, qualidade, rapidez e respeito ao cliente.
          </p>
          <hr>
          <h1 class = "titulotextos"> Valores </h1>
           <p class = "lead">
            O Prontuário Digital visa lorem ipsum para lorem ipsum empresa de design de interiores formada por profissionais habilitados que tem como seu principal objetivo satisfazer todas as necessidades do ponto de vista de decoração de seus milhares de clientes, conquistados em mais de duas décadas de trabalho com compromisso, qualidade, rapidez e respeito ao cliente.    
          </p>
          <hr>
      </div>
    </div>