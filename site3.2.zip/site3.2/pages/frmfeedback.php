<div class = "container-fluid bg-1 text-center" style="padding-top: 60px;">
			<h1 class = "titulotextos"> Feedback </h1>
		</div>
		<div class = "container" id="containerfeed">
			<div class="container">
				<form name="Feedback" method="POST">
                    <label for="fname"> Nome: </label>
                    <input type="text" id="fname" name="firstname" placeholder=" Nome ">
                    <br>
                    <label for="lname"> Sobrenome: </label>
                    <input type="text" id="lname" name="lastname" placeholder=" Sobrenome ">
                    <br>
                    <label for="lemail"> E-mail: </label>
                    <input type="text" id="lemail" name="email" placeholder="E-mail">
                    <br>
                    <label for="subject"> Mensagem: </label>
                    <textarea id="subject" name="subject" placeholder=" Escreva sua mensagem... " style="height:200px"></textarea>
                    <input type="submit" class="btn btn-success btn-block" id="enviar" value="Enviar" onclick="return verificaFeedback()">
                </form>

            </div>
        </div>
        <br> 
		<!-- "RODAPE"-->
    <script language="JavaScript">
      function verificaFeedback()
      {
        var retorno = true;
        if(document.Feedback.fname.value == null || document.Feedback.fname.value == "")
        {
            alert("Por favor, preencher o campo Nome");
            document.Feedback.fname.focus();
            retorno = false;
        }
        else
        {
          if(document.Feedback.lname.value == null || document.Feedback.lname.value == "")
          {
            alert("Por favor, preencher o campo Sobrenome");
            document.Feedback.lname.focus();
            retorno = false;
          }
          else
          {
            if(document.Feedback.lemail.value == null || document.Feedback.lemail.value =="")
            {
              alert("Por favor, preencher o campo E-mail")
              document.Feedback.lemail.focus();
              retorno = false;
            }
            else
            {
              if(document.Feedback.subject.value == null || document.Feedback.subject.value =="")
              {
                alert("Você esqueceu de nós deixar uma mensagem :)");
                document.Feedback.subject.focus();
                retorno= false;
              }
              else
              {
                if(document.Feedback.fname.value.length < 3)
                {
                  alert("Por favor, preencher o campo Nome sem nenhum apelido ou abreviação.")
                  document.Feedback.fname.focus();
                  retorno = false;
                }
                else
                {
                  if(document.Feedback.lname.value.length < 3)
                  {
                    alert("Por favor, preencher o campo Sobrenome sem nenhum apelido ou abreviação.");
                    document.Feedback.lname.focus();
                    retorno=false;
                  }
                  else
                  {
                    if (document.Feedback.lemail.value.length < 3)
                    {
                      alert("Por favor, não programei o email certo ainda :).");
                    document.Feedback.lemail.focus();
                    retorno=false;
                    }
                    else
                    {
                      if (document.Feedback.subject.value.length < 3)
                      {
                        alert("Na menesagem deixar um comentários maior que 3 caracteres.");
                        document.Feedback.subject.focus();
                        retorno = false;
                      }
                      else 
                      {
                        if(retorno == true)
                          {       
                            alert("Muito obrigado pelo Feedback sobre o site :)")
                          }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        return retorno;
      }
    </script>