<div class="modal fade" id="modalLogin" tabindex="1" role="dialog">
        <div class="modal-dialog" role="document">
          <!-- div class="modal-dialog modal-lg (sm- modal menor)" role="document" MODAL MAIOR -->
			<div class="modal-content">
				<div class="modal-header" style="padding:35px 50px;">
					<strong class="modal-title"> FAÇA SEU LOGIN </strong>   
				</div>
				<div class="modal-body" style="padding:40px 50px;">
					<div>
						<form role="form">
							<div class="form-group">
								<label for="usrname"><span class="glyphicon glyphicon-user"></span> Usuário </label>
								<input type="text" class="form-control" id="usrname" placeholder="Insira seu e-mail">
							</div>
							<div class="form-group">
								<label for="psw"><span class="glyphicon glyphicon-eye-open"></span> Senha </label>
								<input type="password" class="form-control" id="psw" placeholder="Digite sua senha">
							</div>
							<div class="checkbox">
								<label><input type="checkbox" value="" checked> Lembrar identificação de usuário </label>
							</div>
							<button type="submit" class="btn btn-success btn-block"> Acessar </button>
							<br>
							<p> Esqueceu o seu usuário ou senha? <a href="#"> Clique aqui </a></p>
						</form>          
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-dismiss="modal">  Fechar </button>   
				</div>
			</div>
        </div>
     </div>