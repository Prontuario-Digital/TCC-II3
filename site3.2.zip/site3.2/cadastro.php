<!DOCTYPE html>
<html lang="en">
<head>
  <title> Cadastro </title>
  <link rel="shortcut icon" type="image/x-icon" href="./Imgs/icon.png">  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="./Scripts/Navbar.css" rel = "stylesheet">
  <link href="./Scripts/Feedback.css" rel = "stylesheet">
    <style>
  body{
    font-family: arial;
  }

#footer{
  background-color: #45c2d4;  
  color: #fff;
  height: 50px;
}
.copyright
{
  text-align: center;
  padding-top: 30px;
}

#cadastro
{
  padding-top: 70px;
  margin-bottom: 20px;
}
ul
    {
      z-index: 1;
      position: fixed;
      width: 100.5%;
      margin-left: -10px;
      margin-right: -10px;
      overflow: hidden;
      list-style: none;
      font-family: arial;
      background-color: #00b8d4;
    }

    li
    {
      margin-left: auto;
      margin-right: auto;
      float: left;
      font-family: arial;
      display: block;
      text-align: center;
      color: #000000;
    } 
    li a 
    {
      display: block;
      padding: 16px 16px;
      text-decoration: none;
      color: #ffffff;
    }
    li a:hover 
    {
      padding: 16px;
      font-weight: bold;
      text-decoration: none;
      background-color: #01788a;
      color: #ffffff;
    }
    .ativo
    {
      padding: 16px ;
      font-weight: bold;
      text-transform: uppercase;
      background-color: #9f0008;
      color: #ffffff;
    }
    #enviar:hover
    {
      background-color: #01788a;
      color: #fff;
    }

</style> 
  </head>
<body>
   <?php
     require_once("./pages/frmnavbaratvcadastro.php");
     require_once("./pages/frmmodalLogin.php");
    ?>


  
<!-- Menu do Cadastro (abas)-->
      <div class="container" id="cadastro">
        <div class="row">
        <h2> Dados Pessoais </h2>
              <article>
                <form name = "Cadastro" action = "" method = "">
            <div class = "form-row">
                <div class = "form-group col-sm-6">
                  <label for = "inputNome"> Nome </label>
                  <input type = "text" id = "vNome"  name = "nome" placeholder = "Nome" class = "form-control">
                </div>
                <div class = "form-group col-sm-6">
                  <label for = "inputData"> Data de Nascimento: </label>
                  <input type = "text" id = "data"  pattern="\d{2}\/\d{2}\/\d{4}" title="Digite corretamente" name = "data" placeholder = "Data" class = "form-control">
                </div>   
                <div class = "form-group col-sm-6">
                  <label for = "inputRg"> RG </label>
                  <input type = "text" id = "rg"  pattern="\d{2}\.\d{3}\.\d{3}-\d{1}" title="Digite corretamente" name = "rg" placeholder = "RG" class = "form-control">
                </div>
                <div class = "form-group col-sm-6">
                  <label for = "inputOrgao"> Órgão Exp.: </label>
                  <input type = "text" id = "orgao" name = "orgao" placeholder = "Orgão emissor" class = "form-control">
                </div>      
                <div class = "form-group col-sm-6">
                  <label for = "inputCpf"> CPF </label>
                  <input type = "text" id = "cpf"  pattern="\d{3}\.\d{3}\.\d{3}-\d{2}" title="Digite corretamente" name = "cpf" placeholder = "CPF" class = "form-control">
                </div>     
                <div class = "form-group col-sm-6">
                  <label for = "inputCartao"> Cartão Cidadão: </label>
                  <input type = "text" id = "cartao"  name = "cartao" placeholder = "Número do cartão" class = "form-control">
                </div>  
                <div class = "form-group col-sm-6">
                  <label for = "inputSexo"> Sexo: </label>
                  <input type = "text" id = "vSexo"  name = "sexo" placeholder = "Sexo" class = "form-control">
                </div> 
                <div class = "form-group col-sm-6">
                  <label for = "email"> E-mail: </label>
                  <input type = "email" id = "email" name = "email" placeholder = "E-mail" class = "form-control">
                </div>
                <div class = "form-group col-sm-6">
                  <label for = "inputCep"> CEP </label>
                  <input type = "text" id = "cep" pattern="\d{5}-\d{3}" title="Digite corretamente" name = "cep" placeholder = "CEP" class = "form-control">
                </div>
                <div class = "form-group col-sm-6">
                  <label for = "rua"> Rua </label>
                  <input type = "text" id = "rua" name = "rua" placeholder = "Rua" class = "form-control">
                </div>
                <div class = "form-group col-sm-6">
                  <label for = "bairro"> Bairro </label>
                  <input type = "text" id = "bairro" name = "bairro" placeholder = "Bairro" class = "form-control">
                </div>
                <div class = "form-group col-sm-6">
                  <label for = "numero"> Número </label>
                  <input type = "number" id = "num" name = "numero" placeholder = "Número" class = "form-control">
                </div>
                <div class = "form-group col-sm-6">
                  <label for = "bairro"> Cidade </label>
                  <input type = "text" id = "cidade" name = "cidade" placeholder = "Cidade" class = "form-control">
                </div>
                <div class = "form-group col-sm-6">
                  <label for = "uf"> Estado </label>
                  <input type = "text" id = "uf" name = "uf" placeholder = "Estado" class = "form-control">
                </div>
                <div class = "form-group col-sm-6">
                  <label for = "inputResidencial"> Telefone Residencial </label>
                  <input type = "text" id = "residencial"  pattern="(\d{2}\)\d{4}\-\d{4}" title="Digite corretamente" name = "residencial" placeholder = "Residencial" class = "form-control">
                </div>   
                <div class = "form-group col-sm-6">
                  <label for = "inputCelular"> Telefone Celular </label>
                  <input type = "text" id = "celular"  pattern="(\d{2}\)\d{5}\-\d{4}" title="Digite corretamente" name = "Celular" placeholder = "Celular" class = "form-control">
                </div>   
        
              <label><input type="checkbox" value="" checked> Ao clicar "Cadastre-se", você aceita os Termos e a Política de Privacidade  </label>        
              <div class = "form-group col-sm-12">
                <input type="button" value="Enviar" class="btn btn-primary" onclick="return verificaCadastro()"></input>
                <button type="button" value="reset" class="btn btn-primary" data-dismiss="modal" style="color: #fff;"> Cancelar</button></a>
              </div>
            </div>
           </div> 
          </div>    

  <script language="javascript">
      function verificaCadastro()
      {
        var retorno = true;
     

        if(document.Cadastro.vNome.value == null || document.Cadastro.vNome.value =="")
        {
          alert("Por favor, preencher campo Nome");
          document.Cadastro.vNome.focus();
          retorno = false;
        }
        else 
        {
          if(document.Cadastro.rg.value == null || document.Cadastro.rg.value=="")
          {
            alert("Por favor, preencher campo RG");
            document.Cadastro.rg.focus();
            retorno = false;
          }
          else
          {
            if (document.Cadastro.cpf.value == null || document.Cadastro.cpf.value == "") 
            {
              alert("Por favor, preencher campo CPF");
              document.Cadastro.cpf.focus();
              retorno = false;
            }
            else
            {
              if (document.Cadastro.vSexo.value == null || document.Cadastro.vSexo.value=="")
              {
                alert("Por favor, preencher campo Sexo");
                document.Cadastro.vSexo.focus();
                retorno = false;
              }
              else
              {
                if(document.Cadastro.cep.value == null || document.Cadastro.cep.value=="")
                {
                  alert("Por favor, preencher campo CEP");
                  document.Cadastro.cep.focus();
                  retorno = false;
                }
                else
                {
                  if(document.Cadastro.residencial.value == null || document.Cadastro.residencial.value == "")
                  {
                    alert("Por favor, preencher campo Telefone Residencial");
                    document.Cadastro.residencial.focus();
                    retorno= false;
                  }
                  else
                  {
                    if(document.Cadastro.data.value== null || document.Cadastro.data.value == "")
                    {
                      alert("Por favor, preencher campo Data de Nascimento");
                      document.Cadastro.data.focus();
                      retorno=false;
                    }
                    else
                    {
                      if(document.Cadastro.orgao.value ==null || document.Cadastro.orgao.value =="")
                      {
                        alert("Por favor, preenche campo Órgão Exp.");
                        document.Cadastro.orgao.focus();
                        retorno= false;
                      }
                      else
                      {
                        if(document.Cadastro.cartao.value == null || document.Cadastro.cartao.value =="")
                        {
                          alert("Por favor, preencher campo Cartão Cidadão");
                          document.Cadastro.cartao.focus();
                          retorno = false;
                        }
                        else
                        {
                         if(document.Cadastro.email.value == null || document.Cadastro.email.value =="")
                          {
                            alert("Por favor, preencher campo Email");
                            document.Cadastro.email.focus();
                            retorno = false;
                          }
                          else
                          {
                            if(document.Cadastro.num.value == null || document.Cadastro.num.value =="")
                            {
                              alert("Por favor, preencher campo Numero");
                              document.Cadastro.num.focus();
                              retorno = false;
                            }
                            else
                            {
                              if(document.Cadastro.celular.value ==null || document.Cadastro.celular.value =="")
                              {
                                alert("Por favor, preencher campo Telefone Celular");
                                document.Cadastro.celular.focus();
                                retorno= false;
                              }

                            }
                          }
                        }
                      }
                    } 
                  }
                }
              }
            }
          }
        }
      return retorno;
      } 
      
    </script>
    <?php
    require_once("./pages/frmfooter.php");
    require_once("./pages/frmmodalLogin.php");
    ?>



  <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.mask.min.js"></script>

  <script type="text/javascript">
    $("#residencial").mask("(00) 0000-00009");
    $("#celular").mask("(00) 00000-0009");
    $("#data").mask("00/00/0000");
    $("#cartao").mask("0 0000000000 0")
    $('#email').mask('SSSSSSSSSSSSSSSS@gmail.com');
    $('#orgao').mask('SSS/SS');
    $('#cep').mask('00000-000');
    $('#cpf').mask('000.000.000-00');
    $("#rg").mask("999.999.999-W", {
    translation: {
      'W': {
        pattern: /[X0-9]/
      }
    },
    reverse: true
  });
                $(document).ready(function() {
            function limpa_formulário_cep() {
                // Limpa valores do formulário de cep.
                $("#rua").val("");
                $("#bairro").val("");
                $("#cidade").val("");
                $("#uf").val("");
            }
            
            //Quando o campo cep perde o foco.
            $("#cep").blur(function() {
                //Nova variável "cep" somente com dígitos.
                var cep = $(this).val().replace(/\D/g, '');
                //Verifica se campo cep possui valor informado.
                if (cep != "") {
                    //Expressão regular para validar o CEP.
                    var validacep = /^[0-9]{8}$/;
                    //Valida o formato do CEP.
                    if(validacep.test(cep)) {
                        //Preenche os campos com "..." enquanto consulta webservice.
                        $("#rua").val("...");
                        $("#bairro").val("...");
                        $("#cidade").val("...");
                        $("#uf").val("...");                     
                        //Consulta o webservice viacep.com.br/
                        $.getJSON("https://viacep.com.br/ws/"+ cep +"/json/?callback=?", function(dados) {
                            if (!("erro" in dados)) {
                                //Atualiza os campos com os valores da consulta.
                                $("#rua").val(dados.logradouro);
                                $("#bairro").val(dados.bairro);
                                $("#cidade").val(dados.localidade);
                                $("#uf").val(dados.uf);
                            } //end if.
                            else {
                                //CEP pesquisado não foi encontrado.
                                limpa_formulário_cep();
                                alert("CEP não encontrado.");
                            }
                        });
                    } //end if.
                    else {
                        //cep é inválido.
                        limpa_formulário_cep();
                        alert("Formato de CEP inválido.");
                    }
                } //end if.
                else {
                    //cep sem valor, limpa formulário.
                    limpa_formulário_cep();
                }
            });
        });
    </script>




  
  </body>
</html>