<!DOCTYPE html>
<html lang="en">
<head>
  <title> Sobre </title>
  <link rel="shortcut icon" type="image/x-icon" href="./Imgs/icon.png">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script> 
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.mask.min.js"></script>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="./Scripts/Navbar.css" rel = "stylesheet">

  </head>




<body>

      <?php
      require_once("./pages/frmnavbaratvsobre.php");
     

      ?>

      <!-- QUEM SOMOS -->
      <div class = "container-fluid bg-1 text-center" style="padding-top: 55px;" >
      <h1 class = "titulotextos" id="teste"> Sobre </h1>
      <div class = "row" id = "quemsomos">
      </div>
       <div class = "container">
          <p class = "lead">
            O Prontuário Digital é um sistema web criado para lorem ipsum empresa de design de interiores formada por profissionais habilitados que tem como seu principal objetivo satisfazer todas as necessidades do ponto de vista de decoração de seus milhares de clientes, conquistados em mais de duas décadas de trabalho com compromisso, qualidade, rapidez e respeito ao cliente. O mercado de design de interiores consiste na arte de planejar e organizar espaços, escolhendo e/ou combinando os diversos elementos de um ambiente, estabelecendo relações estéticas e funcionais, em relação ao que se pretende produzir. Trabalhamos na criação, no desenvolvimento e execução dos projetos e no planejamento e acompanhamento das obras residenciais e comerciais, fazendo estudos preliminares, projetos em 3D com imagens renderizadas, projetos executivos, projetos de paisagismo e de iluminação.
          </p>
          <hr>
          <h1 class = "titulotextos"> Missão </h1>
           <p class = "lead">
            O Prontuário Digital tem como missão lorem ipsum empresa de design de interiores formada por profissionais habilitados que tem como seu principal objetivo satisfazer todas as necessidades do ponto de vista de decoração de seus milhares de clientes, conquistados em mais de duas décadas de trabalho com compromisso, qualidade, rapidez e respeito ao cliente.
          </p>
          <hr>
          <h1 class = "titulotextos"> Visão </h1>
           <p class = "lead">
            O Prontuário Digital visa lorem ipsum para lorem ipsum empresa de design de interiores formada por profissionais habilitados que tem como seu principal objetivo satisfazer todas as necessidades do ponto de vista de decoração de seus milhares de clientes, conquistados em mais de duas décadas de trabalho com compromisso, qualidade, rapidez e respeito ao cliente.
          </p>
          <hr>
          <h1 class = "titulotextos"> Valores </h1>
           <p class = "lead">
            O Prontuário Digital visa lorem ipsum para lorem ipsum empresa de design de interiores formada por profissionais habilitados que tem como seu principal objetivo satisfazer todas as necessidades do ponto de vista de decoração de seus milhares de clientes, conquistados em mais de duas décadas de trabalho com compromisso, qualidade, rapidez e respeito ao cliente.    
          </p>
          <hr>
      </div>
    </div>

    <?php
     require_once("./pages/frmfooter.php");
    ?>




    

</body>
</html>