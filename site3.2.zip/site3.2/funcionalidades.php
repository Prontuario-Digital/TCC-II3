<!DOCTYPE html>
<html lang="en">
<head>
  <title> Funcionalidades </title>
  <link rel="shortcut icon" type="image/x-icon" href="./Imgs/icon.png">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script> 
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.mask.min.js"></script>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="./Scripts/Navbar.css" rel = "stylesheet">

  </head>

    
    <body>
      
      <?php
      require_once("./pages/frmnavbaratvfuncionalidade.php");
      ?>

		<!-- Funcionalidades -->
		<br>
    <br>
    <br>
    <br>
    <br>
		<div class="container">
			<center>
			<h1>Funcionalidades</h1>
			</center>
		<br>
		<br>
		<p class = "lead">
			O Prontuário Digital é um sistema web criado para lorem ipsum empresa de design de interiores formada por profissionais habilitados que tem como seu principal objetivo satisfazer todas as necessidades do ponto de vista de decoração de seus milhares de clientes, conquistados em mais de duas décadas de trabalho com compromisso, qualidade, rapidez e respeito ao cliente. O mercado de design de interiores consiste na arte de planejar e organizar espaços, escolhendo e/ou combinando os diversos elementos de um ambiente, estabelecendo relações estéticas e funcionais, em relação ao que se pretende produzir. Trabalhamos na criação, no desenvolvimento e execução dos projetos e no planejamento e acompanhamento das obras residenciais e comerciais, fazendo estudos preliminares, projetos em 3D com imagens renderizadas, projetos executivos, projetos de paisagismo e de iluminação.
		</p>
		</div>

        <!-- Funcionalidades  (texto e icone e/ou foto) -->
            <div class = "container" id="container">
                <div class="card-deck">         
                  <div class="col-sm-4">
                    <div class="card">                  
                      <div class="card-body">
						<center>
							<img  src="Imgs/minha.png" class="img-fluid"  alt="Card image cap" width="180px" width="180px">
							<h4 class="card-title">Minha Saúde</h4>
						</center>
                          <p> Seu historíco médico. Nulla ut nisi molestie, congue libero eget, vulputate leo. Aliquam erat volutpat. Etiam in augue maximus, finibus tellus quis, cursus lacus. 
                          </p>
                          <a href="#" class="btn btn-primary">Leia mais...</a>
                      </div>
                    </div>
                  </div>         
                  <div class="col-sm-4">
                    <div class="card">                 
                      <div class="card-body">
						<center>
                          <img src="Imgs/remedio.png" class="img-fluid"  alt="Card image cap" width="180px" width="180px">
						  <h4 class="card-title">Medicamentos</h4>
						</center>
                          <p class="card-text"> Farmácia Populares proxímas de você Nulla ut nisi molestie, congue libero eget, vulputate leo. Aliquam erat volutpat. Etiam in augue maximus, finibus tellus quis, cursus lacus. 
                          </p>
                          <a href="#" class="btn btn-primary">Leia mais...</a>
                     </div>
                    </div>
                  </div>
                <div class="col-sm-4">
                  <div class="card">         
                 <div class="card-body">
					<center>
						<img src="Imgs/atendimento.png" class="img-fluid"  alt="Card image cap" width="180px" width="180px">
						<h4 class="card-title">Atendimento</h4>
					</center>				  
                  <p class="card-text"> Histórico de atendimento Nulla ut nisi molestie, congue libero eget, vulputate leo. Aliquam erat volutpat. Etiam in augue maximus, finibus tellus quis, cursus lacus.
                  </p>
                  <a href="#" class="btn btn-primary">Leia mais...</a>
                </div>
              </div>
              </div>        
            </div>
            <br><br>
            <div class="card-deck">      
                <div class="col-sm-4">
                 <div class="card">
                 <div class="card-body">
				 <center>
                    <img  src="Imgs/servico.png" class="img-fluid" alt="Card image cap" width="180px" width="180px">
                  <h4 class="card-title">Serviços de Saúde</h4>
				  </center>
                  <p class="card-text"> Localize um próximo a você  Nulla ut nisi molestie, congue libero eget, vulputate leo. Aliquam erat volutpat. Etiam in augue maximus, finibus tellus quis, cursus lacus. 
                  </p>
                  <a href="#" class="btn btn-primary">Leia mais...</a>
               </div>
              </div>
              </div> 
               <div class="col-sm-4">
                 <div class="card">
                 
                 <div class="card-body">
				 <center>
                    <img src="Imgs/phone.png" class="img-fluid" alt="Card image cap" width="180px" width="180px">
                  <h4 class="card-title">Ouvidoria</h4>
				  </center>
                  <p class="card-text"> Entre em contato  Nulla ut nisi molestie, congue libero eget, vulputate leo. Aliquam erat volutpat. Etiam in augue maximus, finibus tellus quis, cursus lacus. Duis lectus nisi. 
                  </p>
                  <a href="#" class="btn btn-primary">Leia mais...</a>
                </div>
                </div>
              </div>
                <div class="col-sm-4">
                  <div class="card">
                 
                 <div class="card-body">
				<center>
                    <img src="Imgs/hospitais.png" class="img-fluid" alt="Card image cap" width="180px" width="180px">
                   <h4 class="card-tile">Hospitais</h4>              
                </center>  
				  <p class="card-text"> Encontre o hospital mais próximo de você que utiliza o Prontuário Digital.  Nulla ut nisi molestie, congue libero eget, vulputate leo. Aliquam erat volutpat. Etiam in augue maximus.
                  </p>
                  <a href="#" class="btn btn-primary">Leia mais...</a>
                </div>
              </div>
              </div>
              </div>        
          </div>
    

          <?php
          require_once("./pages/frmfooter.php");
          ?>
<script>
    $(document).ready(function(){

        $('.col-sm-4').hover(
            // trigger when mouse hover
            function(){
                $(this).animate({
                    marginTop: "-=1%",
                },200);
            },

            // trigger when mouse out
            function(){
                $(this).animate({
                    marginTop: "0%"
                },200);
            }
        );
    });
</script>


</body>
</html>